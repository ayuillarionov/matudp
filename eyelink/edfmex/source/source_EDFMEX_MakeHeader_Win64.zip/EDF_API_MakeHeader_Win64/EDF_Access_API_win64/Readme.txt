October 8th, 2009

EDF Access API - BETA for Windows x64

This folder contains the EDF Access API C DLL for Windows 64 (lib/win64).

The Examples directory contains the source code for the edf2asc program 
which has been re-written to use the access API. The edf2asc64.exe is found in the example\release directory

The docs directory contains an overview of the API functions.


Be sure to place the edfapi.dll and edfapi.lib in a directory that is in your library path, like windows\system32


Please direct any comments or bug reports to edfapi@eyelinkinfo.com



SR Research Team

